import React from 'react'

const useLocalStorage = () => {
  return (
    <div>
      This is custom hook useLoacalStorage !
    </div>
  )
}

export default useLocalStorage
