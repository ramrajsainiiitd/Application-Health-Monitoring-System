import './App.css';
import MainPage from './modules/MainPage/MainPage';

function App() {
  return (
    <>
      <MainPage />
    </>
  );
}

export default App;
